import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

def load_and_prepare_data():
    '''
    Load and prepare the Indian Liver Patient Dataset
    Returns: X_train, X_test, y_train, y_test, scaler
    '''
    # Load data
    column_names = [
        'Age', 'Gender', 'TB', 'DB', 'Alkphos', 'Sgpt', 
        'Sgot', 'TP', 'ALB', 'A/G', 'Liver_Disease'
    ]
    
    # You need to have ilpd.csv in the data folder
    df = pd.read_csv('data/ilpd.csv', header=None)
    df.columns = column_names
    
    # Convert target: 1,2 → 1,0
    df['Liver_Disease'] = df['Liver_Disease'].map({1: 1, 2: 0})
    
    # Handle missing values
    df['A/G'] = df['A/G'].fillna(df['A/G'].median())
    
    # Separate features and target
    X = df.drop('Liver_Disease', axis=1)
    y = df['Liver_Disease']
    
    # Encode gender
    le = LabelEncoder()
    X['Gender'] = le.fit_transform(X['Gender'])
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    return X_train_scaled, X_test_scaled, y_train, y_test, scaler

if __name__ == "__main__":
    print("Data loading module for Liver Disease Prediction Project")
