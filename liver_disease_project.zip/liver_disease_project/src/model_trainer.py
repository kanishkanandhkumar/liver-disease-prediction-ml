import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import joblib

def train_and_evaluate_models(X_train, X_test, y_train, y_test):
    '''
    Train multiple models and evaluate their performance
    '''
    models = {
        'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
        'Decision Tree': DecisionTreeClassifier(random_state=42, max_depth=5),
        'Random Forest': RandomForestClassifier(random_state=42, n_estimators=100),
        'Support Vector Machine': SVC(random_state=42, probability=True),
        'K-Nearest Neighbors': KNeighborsClassifier(n_neighbors=5),
        'Naive Bayes': GaussianNB()
    }
    
    results = []
    
    for name, model in models.items():
        # Train model
        model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = model.predict(X_test)
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        # Get AUC if possible
        if hasattr(model, "predict_proba"):
            y_pred_prob = model.predict_proba(X_test)[:, 1]
            auc = roc_auc_score(y_test, y_pred_prob)
        else:
            auc = None
        
        results.append({
            'Model': name,
            'Accuracy': accuracy,
            'Precision': precision,
            'Recall': recall,
            'F1-Score': f1,
            'AUC': auc
        })
        
        # Save the best model (Logistic Regression)
        if name == 'Logistic Regression':
            joblib.dump(model, 'models/liver_disease_model.pkl')
            print(f"✓ Saved Logistic Regression model")
    
    return pd.DataFrame(results)

def predict_new_patient(patient_data, model_path='models/liver_disease_model.pkl'):
    '''
    Make prediction for a new patient
    '''
    model = joblib.load(model_path)
    prediction = model.predict(patient_data)
    probability = model.predict_proba(patient_data)
    
    return prediction, probability

if __name__ == "__main__":
    print("Model training module for Liver Disease Prediction Project")
